#<cldoc:Credits and Acknowledgments>

&#8291;

VoodooI2C has evolved massively since its infancy. We would surely not be where we are today without the many fantastic contributions made by many talented people across the world. I am very grateful for their help and many dedicated workhours in realising this open source project. The people who I can list off the top of my head are

 - [@coolstar](https://github.com/coolstar)
 - [@blankmac](https://github.com/blankmac)
 - [@kprinssu](https://github.com/kprinssu)
 - [@nuudles](https://github.com/nuudles)
 - [@ben9923](https://github.com/ben9923)
 - [@RehabMan](https://github.com/RehabMan)
 - [@westeri](https://github.com/westeri)

If you feel that you have been missed out in this list then please do let me know!